package Exceptions;

public class InvalidFormat extends Exception{

}
