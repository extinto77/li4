package Exceptions;

public class NoMatch extends Exception{
}
