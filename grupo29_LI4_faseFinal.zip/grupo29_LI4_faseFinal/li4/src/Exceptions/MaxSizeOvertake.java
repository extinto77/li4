package Exceptions;

public class MaxSizeOvertake extends Exception{
}
