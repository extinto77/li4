package Exceptions;

public class BDFailedConnection extends Exception{
}
