package Exceptions;

public class AddingError extends Exception{
}
